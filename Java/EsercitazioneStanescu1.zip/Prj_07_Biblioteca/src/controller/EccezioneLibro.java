package controller;

public class EccezioneLibro extends Exception{
	    public EccezioneLibro(String Errore) {
	        super(Errore);
	    }
}
