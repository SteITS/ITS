package com.stwfy.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stwfy.entities.Prodotto;

public interface ProdottoDAO extends JpaRepository<Prodotto, Integer>{

	
	
}
