package cicli;

public class ProvaDiCarattere {

	public static void main(String[] args) {
		
		for(int i=0;i<256;i++) {
			System.out.println("il valore di i: " +i+" " +(char)i);
			
			
		}
	}
}
