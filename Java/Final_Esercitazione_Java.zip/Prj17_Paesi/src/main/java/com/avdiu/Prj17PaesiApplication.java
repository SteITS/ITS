package com.avdiu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prj17PaesiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Prj17PaesiApplication.class, args);
	}

}
