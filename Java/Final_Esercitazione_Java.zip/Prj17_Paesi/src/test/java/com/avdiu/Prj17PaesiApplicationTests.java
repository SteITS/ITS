package com.avdiu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj17PaesiApplicationTests {

	@Test
	void contextLoads() {
	}

}
