package com.stanescu.interfacce;

public interface ProvaZero {

	
}
