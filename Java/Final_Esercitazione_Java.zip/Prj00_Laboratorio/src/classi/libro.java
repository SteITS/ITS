package classi;

public class libro {

	private int codice;
	private String titolo;
	private String autore;
}
