package database;

public class demo {

	public static void main(String[] args) {
		Connessione c= new Connessione();
		c.connetti();

	}

}
