package com.stwfy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj14PaesiApplicationTests {

	@Test
	void contextLoads() {
	}

}
