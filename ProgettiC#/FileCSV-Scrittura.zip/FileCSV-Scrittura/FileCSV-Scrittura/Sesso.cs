﻿namespace FileCSV_Scrittura
{
    internal enum Sesso
    {
        ALTRO,F,M
    }
}