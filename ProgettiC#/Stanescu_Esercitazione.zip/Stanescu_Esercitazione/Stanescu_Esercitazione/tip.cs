﻿namespace Stanescu_Esercitazione
{
    internal enum tip
    {
        Carrozzeria,Meccanica
    }
}