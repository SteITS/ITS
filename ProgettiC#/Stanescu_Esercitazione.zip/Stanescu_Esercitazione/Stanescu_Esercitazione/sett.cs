﻿namespace Stanescu_Esercitazione
{
    internal enum sett
    {
        Auto,Moto
    }
}