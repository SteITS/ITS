﻿namespace BikeStores.Data
{
    public class Class1
    {

    }
}
