debra.burks@yahoo.com --> Customers
fabiola.jackson@bikes.shop --> Employees
admin@bikes.shop --> Admins
mireya.copeland@bikes.shop --> Employees

password: @Bike-2024