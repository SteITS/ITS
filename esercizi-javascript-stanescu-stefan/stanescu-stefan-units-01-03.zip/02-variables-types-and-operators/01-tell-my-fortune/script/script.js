let children=3, partner = "bib", loc ="Turin", job="plumber"

console.log("You will be a ",job ," in ",loc,", and married to ",partner," with ",children," kids");