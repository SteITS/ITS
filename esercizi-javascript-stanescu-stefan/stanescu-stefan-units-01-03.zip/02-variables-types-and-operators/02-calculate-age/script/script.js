let bday=2000, year=2055;

console.log("You will be a either",year-bday,"or",year-bday-1,"in",year);