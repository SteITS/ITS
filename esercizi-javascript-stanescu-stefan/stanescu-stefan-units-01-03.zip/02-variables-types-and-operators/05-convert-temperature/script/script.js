let c=23, f;

console.log(c,"C is",f=(c*1.8)+32,"F")

console.log(f,"F is",(f-32)/1.8)