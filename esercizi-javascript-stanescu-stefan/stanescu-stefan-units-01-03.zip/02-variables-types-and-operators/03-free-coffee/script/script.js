let cage = 23, fage = 75, cof=2;

console.log("You will need",(fage-cage)*(365*cof),"cups of coffee to last you until the ripe old age of",fage)