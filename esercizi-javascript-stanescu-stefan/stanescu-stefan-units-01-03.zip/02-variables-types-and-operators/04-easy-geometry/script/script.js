let r=3.2;

console.log("The circumference is",2*Math.PI*r,"\nThe area is:",Math.PI*Math.pow(r,2))