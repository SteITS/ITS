function calculateDogAge(dage,hage) {
    console.log("Your dog is "+dage*7+" years old in human years!")
    console.log("You  "+hage/7+" years old in dog years!")
}

let dage = 8,hage = 32
calculateDogAge(dage,hage);