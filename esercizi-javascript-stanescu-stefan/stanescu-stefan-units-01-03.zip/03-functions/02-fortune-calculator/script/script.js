let children,partner,geoloc,job;

function fortune(children,partner,geoloc,job){
    console.log("You will be a ",job ," in ",geoloc,", and married to ",partner," with ",children," kids");
}

fortune(2,"Elysse","Rome","Programmer")
fortune(4,"Leath","Moscow","Plumber")
fortune(1,"Vaeri","Budapest","Airplane pilot")