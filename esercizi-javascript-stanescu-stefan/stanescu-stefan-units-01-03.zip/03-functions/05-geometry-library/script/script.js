function calcCircumference(r){
    console.log(2*Math.PI*r);
}

function calcArea(r){
    console.log(Math.PI*Math.pow(r,2));
}

let r = 6;
calcCircumference(r);
calcArea(r);